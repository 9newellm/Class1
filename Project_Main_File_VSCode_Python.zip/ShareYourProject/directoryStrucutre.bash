/your-project-directory
│
├── VisualStudioSetup
│   └── extensions.txt
└── generate_extensions.py
└── generate_pipInstallRequriments.py
