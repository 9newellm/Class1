
# This is the project config. 
import os


## Set Variables <DO NOT CHANGEG>
# Get the current working directory
# active_path = os.getcwd()

## User Variables <Configurable> 

ISTEST = True # Running Test File ... for code configuration 
ISNAME_FOR_TEST =  './smooth_simulated_raman_test_data.xlsx'